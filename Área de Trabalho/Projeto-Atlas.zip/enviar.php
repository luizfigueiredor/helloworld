<?php

use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;

// ===================================================
// CONFIGURAÇÃO INICIAL
// ===================================================

// Carrega o PHPMailer instalado pelo Composer
require __DIR__ . '/vendor/autoload.php';

// Define que o PHP responderá em JSON
header('Content-Type: application/json; charset=UTF-8');

// ===================================================
// FUNÇÃO PARA RETORNAR RESPOSTAS
// ===================================================

function responder(
    bool $sucesso,
    string $mensagem,
    int $statusCode = 200
): void {
    http_response_code($statusCode);

    echo json_encode(
        [
            'success' => $sucesso,
            'message' => $mensagem,
        ],
        JSON_UNESCAPED_UNICODE
    );

    exit;
}

// ===================================================
// VERIFICAÇÃO DO MÉTODO
// ===================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(
        false,
        'Método de requisição inválido.',
        405
    );
}

// ===================================================
// RECEBIMENTO DOS DADOS
// ===================================================

$nome  = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$msg   = trim($_POST['msg'] ?? '');

// ===================================================
// VALIDAÇÃO DOS CAMPOS
// ===================================================

if ($nome === '' || $email === '' || $msg === '') {
    responder(
        false,
        'Preencha todos os campos.',
        400
    );
}

// ===================================================
// VALIDAÇÃO DO E-MAIL
// ===================================================

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    responder(
        false,
        'Informe um endereço de e-mail válido.',
        400
    );
}

// ===================================================
// LIMITES DOS CAMPOS
// ===================================================

if (mb_strlen($nome) > 150) {
    responder(
        false,
        'O nome informado é muito longo.',
        400
    );
}

if (mb_strlen($email) > 254) {
    responder(
        false,
        'O e-mail informado é muito longo.',
        400
    );
}

if (mb_strlen($msg) > 10000) {
    responder(
        false,
        'A mensagem é muito longa.',
        400
    );
}

// ===================================================
// CONFIGURAÇÃO DO PHPMailer
// ===================================================

$mail = new PHPMailer(true);

try {

    // ---------------------------------------------------
    // CONFIGURAÇÃO SMTP
    // ---------------------------------------------------

    $mail->isSMTP();

    $mail->Host = 'mail.theatlasdev.com.br';

    $mail->SMTPAuth = true;

    $mail->Username = 'suporte@theatlasdev.com.br';

    // COLOQUE AQUI A SENHA REAL DA CONTA
    $mail->Password = '1@Suporteatlas';

    // SSL através da porta 465
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;

    $mail->Port = 465;

    // ---------------------------------------------------
    // CONFIGURAÇÃO DE CARACTERES
    // ---------------------------------------------------

    $mail->CharSet = 'UTF-8';
    $mail->Encoding = 'base64';

    // ---------------------------------------------------
    // REMETENTE
    // ---------------------------------------------------

    $mail->setFrom(
        'suporte@theatlasdev.com.br',
        'Formulário do site Atlas'
    );

    // ---------------------------------------------------
    // DESTINATÁRIO
    // ---------------------------------------------------

    $mail->addAddress(
        'suporte@theatlasdev.com.br',
        'Atlas'
    );

    // ---------------------------------------------------
    // REPLY-TO
    // ---------------------------------------------------

    $mail->addReplyTo(
        $email,
        $nome
    );

    // ===================================================
    // PREPARAÇÃO DOS DADOS
    // ===================================================

    $nomeSeguro = htmlspecialchars(
        $nome,
        ENT_QUOTES,
        'UTF-8'
    );

    $emailSeguro = htmlspecialchars(
        $email,
        ENT_QUOTES,
        'UTF-8'
    );

    $mensagemSegura = nl2br(
        htmlspecialchars(
            $msg,
            ENT_QUOTES,
            'UTF-8'
        )
    );

    // ===================================================
    // ASSUNTO
    // ===================================================

    $mail->Subject = 'Nova mensagem recebida pelo site Atlas';

    // ===================================================
    // E-MAIL HTML
    // ===================================================

    $mail->isHTML(true);

    $mail->Body = '
        <!DOCTYPE html>
        <html lang="pt-BR">

        <head>
            <meta charset="UTF-8">
            <title>Nova mensagem - Atlas</title>
        </head>

        <body
            style="
                margin: 0;
                padding: 30px;
                background: #f4f4f4;
                font-family: Arial, Helvetica, sans-serif;
                color: #222;
            "
        >

            <div
                style="
                    max-width: 650px;
                    margin: 0 auto;
                    background: #ffffff;
                    padding: 35px;
                    border-radius: 8px;
                    border: 1px solid #e5e5e5;
                "
            >

                <h2
                    style="
                        margin-top: 0;
                        color: #111;
                    "
                >
                    Nova mensagem recebida pelo site
                </h2>

                <div style="margin-top: 30px;">

                    <p>
                        <strong>Nome:</strong><br>
                        ' . $nomeSeguro . '
                    </p>

                    <p>
                        <strong>E-mail:</strong><br>
                        ' . $emailSeguro . '
                    </p>

                    <p>
                        <strong>Mensagem:</strong>
                    </p>

                    <div
                        style="
                            padding: 20px;
                            background: #f7f7f7;
                            border-left: 3px solid #222;
                            line-height: 1.6;
                        "
                    >
                        ' . $mensagemSegura . '
                    </div>

                </div>

                <p
                    style="
                        margin-top: 35px;
                        font-size: 12px;
                        color: #888;
                    "
                >
                    Esta mensagem foi enviada através do formulário
                    de contato do site Atlas.
                </p>

            </div>

        </body>
        </html>
    ';

    // ===================================================
    // VERSÃO EM TEXTO PURO
    // ===================================================

    $mail->AltBody =
        "Nova mensagem recebida pelo site Atlas\n\n" .
        "Nome: {$nome}\n" .
        "E-mail: {$email}\n\n" .
        "Mensagem:\n{$msg}\n";

    // ===================================================
    // ENVIA O E-MAIL
    // ===================================================

    $mail->send();

    // ===================================================
    // SUCESSO
    // ===================================================

    responder(
        true,
        'Mensagem enviada com sucesso!',
        200
    );
} catch (Exception $e) {

    // ===================================================
    // ERRO
    // ===================================================

    /*
     * Não mostramos o erro técnico do PHPMailer
     * para o visitante.
     *
     * Isso evita revelar informações internas
     * do servidor ou da configuração SMTP.
     */

    responder(
        false,
        'Não foi possível enviar a mensagem. Tente novamente mais tarde.',
        500
    );
}
