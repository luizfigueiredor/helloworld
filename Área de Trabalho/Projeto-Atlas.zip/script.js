// ===================================================
// TELA DE CARREGAMENTO (LOADER)
// Quando a página termina de carregar tudo (imagens, fontes etc.),
// esperamos 1,9 segundo e depois escondemos a tela preta com "Atlas".
// ===================================================
window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('loader').classList.add('done');
  }, 1900);
});

// ===================================================
// ANIMAÇÃO "APARECER AO ROLAR" (scroll reveal)
// Pega todos os elementos com a classe "reveal" (que começam invisíveis)
// e fica observando: quando 15% do elemento entra na tela,
// adiciona a classe "in", que o CSS usa para mostrá-lo suavemente.
// Depois de aparecer uma vez, para de observar (não repete).
// ===================================================
const reveals = document.querySelectorAll('.reveal');
const obs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in');
      obs.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });
reveals.forEach(el => obs.observe(el));

// ===================================================
// EFEITO DE PROFUNDIDADE (PARALLAX) NA BOLHA DE LUZ DO HERO
// Conforme o mouse se move pela tela, a bolha de luz de fundo
// se desloca um pouquinho na direção contrária, criando
// sensação de profundidade.
// ===================================================
const glow = document.querySelector('.hero-glow');
window.addEventListener('mousemove', (e) => {
  if (!glow) return; // se não existir esse elemento na página, não faz nada
  const x = (e.clientX / window.innerWidth - 0.5) * 30;
  const y = (e.clientY / window.innerHeight - 0.5) * 30;
  glow.style.transform = `translate(${x}px, ${y}px)`;
});

// ===================================================
// ROTAÇÃO SUTIL DE UM "NÓ" (ELEMENTO COM ID "atlasKnot")
// Se existir um elemento com esse id na página, ele gira devagar
// conforme a pessoa rola a tela para baixo.
// Obs: esse elemento não aparece no HTML atual, então esse trecho
// fica "adormecido" até que ele seja adicionado em algum lugar.
// ===================================================
const knot = document.getElementById('atlasKnot');
window.addEventListener('scroll', () => {
  if (!knot) return;
  const scrolled = window.scrollY;
  const rotate = (scrolled * 0.02) % 360;
  knot.style.transformOrigin = '200px 240px';
  knot.style.transform = `rotate(${rotate * 0.3}deg)`;
});

// ===================================================
// BOTÃO DE MENU MOBILE (versão simples/provisória)
// Ao clicar no botão "Menu" (que só aparece no celular),
// o código passa por todos os links do menu e rola a tela
// até o último deles. É um comportamento bem básico —
// ainda não abre/fecha um menu de verdade.
// ===================================================
/* ===================================================
   MENU HAMBÚRGUER (mobile)
   =================================================== */

const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

hamburger.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  hamburger.textContent = isOpen ? '✕' : '☰';
  hamburger.setAttribute('aria-expanded', isOpen);
});

// Permite abrir o menu também pelo teclado (Enter/Espaço), já que
// o hambúrguer é uma <div role="button"> e não um <button> nativo
hamburger.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    hamburger.click();
  }
});

// Fecha o menu automaticamente ao clicar em qualquer link
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    hamburger.textContent = '☰';
    hamburger.setAttribute('aria-expanded', 'false');
  });
});

/* ===================================================
   ALTERNAR TEMA ESCURO/CLARO
   O site nasce no tema escuro (padrão do style.css).
   Ao clicar no botão de sol/lua, adiciona ou remove a
   classe "light" na tag <html>, que faz o CSS trocar
   as cores. A escolha da pessoa fica salva no navegador
   (localStorage), então ela não precisa escolher de novo
   toda vez que visitar o site.
   =================================================== */

const html = document.documentElement;
const themeToggle = document.getElementById('theme-toggle');

// Recupera a preferência salva de uma visita anterior.
// Se não houver nada salvo, o site continua no escuro (padrão).
const savedTheme = localStorage.getItem('atlas-theme');
if (savedTheme === 'light') {
  html.classList.add('light');
}

themeToggle.addEventListener('click', () => {
  html.classList.toggle('light');
  localStorage.setItem('atlas-theme', html.classList.contains('light') ? 'light' : 'dark');
});

/* ===================================================
ENVIO DO FORMULÁRIO
=================================================== */

const contactForm = document.getElementById('contact-form');
const submitBtn = document.getElementById('submit-btn');
const formStatus = document.getElementById('form-status');

contactForm.addEventListener('submit', async (e) => {

  // Impede o navegador de sair da página
  e.preventDefault();

  // Ativa animação
  submitBtn.classList.add('loading');
  submitBtn.disabled = true;

  // Limpa mensagem anterior
  formStatus.className = 'form-status';
  formStatus.textContent = '';

  try {

    const formData = new FormData(contactForm);

    const response = await fetch(contactForm.action, {
      method: 'POST',
      body: formData
    });

    const result = await response.json();

    // Verifica se o PHP informou sucesso
    if (!response.ok || !result.success) {
      throw new Error(result.message || 'Erro ao enviar a mensagem.');
    }

    // Remove o loading
    submitBtn.classList.remove('loading');

    // Mostra sucesso
    formStatus.textContent = result.message;
    formStatus.classList.add('show', 'success');

    // Limpa os campos
    contactForm.reset();


  } catch (error) {

    // Remove o loading
    submitBtn.classList.remove('loading');

    // Mostra erro
    formStatus.textContent =
      error.message || 'Não foi possível enviar a mensagem.';

    formStatus.classList.add('show', 'error');


  } finally {

    // Libera o botão
    submitBtn.disabled = false;


  }

});